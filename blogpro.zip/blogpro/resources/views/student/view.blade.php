@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
		<a href="{{ url('/student/create') }}" class="btn btn-primary" style="margin-left:900px;">Back</a>
            <div class="panel panel-default">
                <div class="panel-heading">Student list</div>

                <div class="panel-body">
				<table class="table table-striped">
					<tr>
						<th>Firstname</th>
						<th>Lastname</th>
						<th>Department</th>
						<th>Actions</th>
					</tr>
					@foreach($student as $students)
						<tr>
							<td>{{$students->firstname}}</td>
							<td>{{$students->lastname}}</td>
							<td>{{$students->department}}</td>
							<td><a href="{{ route('update/student', $students->id) }}">Edit </a>||
								<a href="{{ route('delete/student', $students->id) }}">Delete</a></td>
						</tr>
					@endforeach
				</table>
				
				</div>
            </div>
        </div>
    </div>
</div>

@endsection