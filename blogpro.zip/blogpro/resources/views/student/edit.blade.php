@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Create Student</div>
				<form class="form-horizontal" role="form" method="POST" action="">
                       <input type="hidden" name="_token" value="{{ csrf_token() }}">
					
                <div class="panel-body">
                    <div class="form-group">
						<label class="col-md-4 control-label">FirstName</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="fname" value="{{ Input::old('firstname', $student->firstname) }}">
						</div>
					</div>
					<div class="form-group">
						<label  class="col-md-4 control-label">LastName</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="lname" value="{{ Input::old('lastname', $student->lastname) }}">
						</div>
					</div>
					<div class="form-group">
						<label  class="col-md-4 control-label">Department</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="dept" value="{{Input::old('department', $student->department) }}">
						</div>
					</div>
					<div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i> Submit
                                </button>
								<a href="{{ url('student/view') }}" class="btn btn-primary">Back</a>
							</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection