<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
		<a href="<?php echo e(url('/student/create')); ?>" class="btn btn-primary" style="margin-left:900px;">Back</a>
            <div class="panel panel-default">
                <div class="panel-heading">Student list</div>

                <div class="panel-body">
				<table class="table table-striped">
					<tr>
						<th>Firstname</th>
						<th>Lastname</th>
						<th>Department</th>
						<th>Actions</th>
					</tr>
					<?php foreach($student as $students): ?>
						<tr>
							<td><?php echo e($students->firstname); ?></td>
							<td><?php echo e($students->lastname); ?></td>
							<td><?php echo e($students->department); ?></td>
							<td><a href="<?php echo e(route('update/student', $students->id)); ?>">Edit </a>||
								<a href="<?php echo e(route('delete/student', $students->id)); ?>">Delete</a></td>
						</tr>
					<?php endforeach; ?>
				</table>
				
				</div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>