<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Student;
use App\Http\Requests;
use Input;
use Redirect;

class StudentController extends Controller
{
    //
	public function index()
	{
		return view('student.create');
	}
	public function create()
	{
		$student = new Student;
		$student->firstname=Input::get('fname');
		$student->lastname=Input::get('lname');
		$student->department=Input::get('dept');
		$student->save();
		
		$student=Student::all();
		return view('student.view',compact('student'));
	}
	public function show()
	{
		$student=Student::all();
		return view('student.view',compact('student'));
	
	}
	public function update($student)
	{
		$students=Student::find($student);
		return view('student.edit',compact('student'));
	}
	public function getEdit($studentId)
    {
       $student = Student::find($studentId);
            
            return view('student.edit',compact('student'));
        
    }
	public function postEdit($studentId)
    {
        $student = Student::find($studentId); 
           $student->firstname=e(Input::get('fname'));
           $student->lastname=e(Input::get('lname'));
		   $student->department=e(Input::get('dept'));

            $student->save();
			
              $student=Student::all();
		return view('student.view',compact('student'));
	}
	public function getDelete($studentId)
    {
        $student = Student::find($studentId); 
           
            $student->delete();
			
              $student=Student::all();
		return view('student.view',compact('student'));
	}
	
}
